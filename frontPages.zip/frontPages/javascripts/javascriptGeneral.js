function lastModifiedString()
{
	var result;
	lastmod = document.lastModified // get string of last modified date
	lastmoddate = Date.parse(lastmod)   // convert modified string to date
	if(lastmoddate == 0)
	{               // unknown date (or January 1, 1970 GMT)
   	result = "Unknown";
   }
	else
	{
   	result = lastmod;
	}
	return result;		
}

function footer()
{
	document.write("Last modified: " + lastModifiedString());
}

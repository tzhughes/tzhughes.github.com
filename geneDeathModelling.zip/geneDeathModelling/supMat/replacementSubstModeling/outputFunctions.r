#Write parameters, rss and nb datapoints to file
write.fit <- function(nls2.fit, data, result.type){
framing.string <- paste("###########################################RESULTS=", result.type, "\n", sep="");
cat(framing.string);
#Output the number of datapoints
cat("datapoints=", dim(data)[1], "\n");
#output RSS
cat("RSS=", nls2.fit$rss.unweighted, "\n");
#output sigma2
cat("sigma2=", nls2.fit$sigma2, "\n");
#Output the parameters, standard errors and confidence intervals.
cat("Parameters=\n");
param <- coef.nls2(nls2.fit);
print(param);
cat("Confidence intervals (95%)=", "\n");
conf <- confidence.nls2(nls2.fit, conf.level=0.95); 
print(conf$normal.conf.int);
cat(framing.string);
}

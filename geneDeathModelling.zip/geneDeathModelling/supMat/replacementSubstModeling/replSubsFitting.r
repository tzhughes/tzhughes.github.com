#Fit the function to the replacement data.

#General procedure:
#Estimate the model.repl.low.hughes using quasilikelihood and modelling the variance as the data is heteroscedastic at these values of S


#Loading all necessary data
data <- read.table("../../01_filteredData/canisFamiliaris/bestAltSplices.tab", header=FALSE);
data.relevant <- data.frame(R=data[,6],S=data[,7]);
data.low <- data.relevant[(data.relevant$S >= 0.0) & (data.relevant$S <= 3.0) & (data.relevant$R <= 3.0),];


#Loading nls2
attach("~/bin/R-2.4.0/library/nls2/.RData");
loadnls2();

#Load the output functions
source("~/data/project_geneDeathModelling/code/r/outputFunctions.r", echo=T);

#Control the data to be saved and output during the estimation process
#Control
ctrl=list(freq=-1,fitted=FALSE, sv.fitted=T, sv.as.var=T, sv.B.varZ.B=F, sv.correlation=F, sv.data=T, sv.est.eq=F, sv.estim=T, sv.deriv.fct=F,  sv.mu=F, sv.residuals=T, sv.num.res=T, sv.odes=F, sv.W=F, sv.Z=F);
options(warn=0);

#Estimate the model.repl.low.hughes using quasilikelihood and modelling the variance as the data is heteroscedastic at these values of S

#Model
mdl.low=list(file="/Home/strandfuru/tim/data/project_geneDeathModelling/code/r/model.repl.low.hughes", inf.beta=c(0.0,0.0,0.0), inf.theta=c(0.0,0.0,0.0), eq.theta=c(NaN,NaN,NaN));
#Context
#Use realistic start values for the parameters of the variance and regression functions
ctx.low=list(beta.start=c(236,6.38,3.89), theta.start=c(0.02,0.60,2.25), max.iters=1000, algorithm="GM", max.err.c1=40,  max.err.c2=40, max.stop.crit=1e-8);
#Method
#Use QLTB as the errors are not normally distributed
method.low=c("QLTB");
#Fit
nls2.low <- nls2(data=data.low, model=mdl.low, stat.ctx=ctx.low, method=method.low, control=ctrl);

result.type <- "low";
write.fit(nls2.low, data.low, result.type);


#Test whether the slope of the variance function is asymptotically 0
temp <- paste("###########################################RESULTS=", "wald_test_var_asymp_slope", "\n", sep="");
cat(temp);
coef.low <- coef.nls2(nls2.low);
cat("Wald_statistic_var_asymp_slope=", (coef.low$beta[1]**2)/(coef.low$std.error[4]**2), "\n", sep="");
#cat("X2_95_1=",qchisq(0.95,1),"\n", sep="");
cat(temp);

#1% 5% 95% and 99% percentiles
temp <- paste("###########################################RESULTS=", "quantiles", "\n", sep="");
cat(temp);
quantiles <- quantile(nls2.low$s.residuals,  probs=c(0.01,0.05,0.95,0.99));
cat("quantile_1_percent=", quantiles[1],"\n", sep="");
cat("quantile_5_percent=", quantiles[2],"\n", sep="");
cat("quantile_95_percent=", quantiles[3],"\n", sep="");
cat("quantile_99_percent=", quantiles[4],"\n", sep="");
cat(temp);

#Test whether neutrality can be rejected
loadnls2(psi="");
temp <- paste("###########################################RESULTS=", "wald_test_neutrality", "\n", sep="");
cat(temp);
neutrality.wald <- wald.nls2(nls2.low, "/Home/strandfuru/tim/data/project_geneDeathModelling/code/r/neutrality.wald")
cat("Wald_statistic_neutrality=", neutrality.wald$statistic, "\n", sep="");
cat("X2_95_1=",qchisq(0.95,1),"\n", sep="");
cat(temp);


#Exit
q();



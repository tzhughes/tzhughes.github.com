#Fit the weibull and exponential functions to the survival data.
#Carry out a likelihood ratio test to test whether the weibull function provides a superior fit to the exponential function.

#create a dataframe containing the data used in the regression
data <- read.table("../03_geneDeath/canisFamiliaris/silentSubstCounts_bucketSize_0.01_median.tab", header=FALSE);#No header available for this data.
relevant.data <- data.frame(S=data[,1],N=data[,2]);
used.data <- relevant.data[relevant.data$S <= 0.3,];

#Loading nls2
attach("~/bin/R-2.4.0/library/nls2/.RData");
loadnls2();

source("~/data/project_geneDeathModelling/code/r/outputFunctions.r", echo=T);

#Model
mdl=list(file="/Home/strandfuru/tim/data/project_geneDeathModelling/code/r/model.survival");
#Context
ctx=list(theta.start=c(1000,-4.0,0.2), max.iters=10000, max.stop.crit=10e-10, algorithm="GM");
#Method
method=c("MLT");
#Control
ctrl=list(freq=-1,fitted=FALSE);

#Fit the unrestricted model
nls2.unrestricted <- nls2(data=used.data, model=mdl, stat.ctx=ctx, method=method, control=ctrl);

#Impose restriction d=1.0
mdl=list(file="/Home/strandfuru/tim/data/project_geneDeathModelling/code/r/model.survival",eq.theta=c(NaN,NaN,1.0));
#Modify the starting parameters to be consistent with restriction on d
ctx=list(theta.start=c(1000,-4.0,1.0), max.iters=10000, max.stop.crit=10e-10, algorithm="GM");

#Fit the restricted model
nls2.restricted <- nls2(data=used.data, model=mdl, stat.ctx=ctx, method=method, control=ctrl);

#Unrestricted model
model.type <- "unrestricted";
write.fit(nls2.unrestricted, used.data, model.type);

#Restricted model
model.type <- "restricted";
write.fit(nls2.restricted, used.data, model.type);

#Compute the likelihood ratio test
temp <- paste("#####RESULTS=", "likelihood_ratio", "\n", sep="");
cat(temp);
cat("LR=", dim(used.data)[1]*(nls2.restricted$loglik-nls2.unrestricted$loglik), "\n", sep="");
cat("X2_95_1=", qchisq(0.95,1), "\n", sep="");
cat(temp, sep="");

#Exit
q();


